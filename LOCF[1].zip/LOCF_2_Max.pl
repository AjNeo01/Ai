% Maximum of two numbers

start :-
	write('Enter the first number: '),	%Prompt for first number
	read(Num1),	%Read the first number
	write('Enter the second number: '),	%Prompt for second number
	read(Num2),	%Read the second number

	max(Num1, Num2, Result),	%Calculate the max
	write('The maximum number is: '), write(Result).	%Display the result

%Defining max function
max(X, Y, Result):- X >= Y, Result is X.
max(X, Y, Result):- X < Y, Result is Y.