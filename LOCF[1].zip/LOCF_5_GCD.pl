%GCD of two numbers
start:-
	write('Enter first number: '),	%Prompt first number
	read(Num1),	%Reading first number
	write('Enter second number: '),	%Prompt second number
	read(Num2),	%Reading second number
	
	gcd(Num1, Num2, Ans),
	write('The GCD of '), write(Num1), write(' and '), write(Num2), write(' is '), write(Ans).


gcd(Num1, 0, Num1):- !.	%Base Case: GCD of X and 0 is X
gcd(Num1, Num2, Ans):-
	Temp is Num1 mod Num2,
	gcd(Num2, Temp, Ans).	%Calling gcd recursively