%Fibonacci Series

start:-
	write('Enter the nth term: '),	%Prompt to enter a number
	read(N),	%Reading the nth term
	
	(N < 0 -> write('Number must be positive')
	;
	fib(N, T),	%Generate the fibonacci series
	write(T), write('th term in fibonacci series is '), write(T)
	).

fib(0, 0).	%Base Case: 0th term is 0
fib(1, 1).	%Base Case: 1st term is 1

fib(N, T) :-
	N1 is N-1,
	N2 is N-2,
	fib(N1, T1),
	fib(N2, T2),
	T is T1+T2.
	fib(N, T).