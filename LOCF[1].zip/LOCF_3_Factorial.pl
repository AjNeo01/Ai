%Factorial of a number

start:-
	write('Enter a number: '),	%Prompt to enter a number
	read(N),	%Reading the number
	
	(N < 0 -> 
		write('The number must be positive')
	;	fact(N, Result),	%Calculating the factorial
		write('The factorial of '), write(N), write(' is '), write(Result)
	).

fact(0, 1). %Base Case: 0! = 1
fact(1, 1). %Base Case: 1! = 1

fact(N, Result):-
	N1 is N-1,	%Decrement N by 1
	fact(N1, Result1),	%Recursively calculate (N-1)!
	Result is N*Result1.	%N*fact(N-1)