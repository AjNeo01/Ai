% Sum of two numbers

start :-
	write('Enter the first number: '),	%Prompt for first number
	read(Num1),	%Read the first number
	write('Enter the second number: '),	%Prompt for second number
	read(Num2),	%Read the second number

	sum(Num1, Num2, Result),	%Calculate the sum
	write('The sum is: '), write(Result).	%Display the result

%Defining sum function
sum(X, Y, Result):- Result is X+Y.