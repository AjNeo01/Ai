%Multiplication of two numbers

start:-
	write('Enter the first number: '),	%Prompt to enter a number
	read(N1),	%Reading the first number
	write('Enter the second number: '),	%Prompt to enter a number
	read(N2),	%Reading the second number
	
	mult(N1, N2, Result),	%Calculating the multiplication
	write(N1), write(' * '), write(N2), write(' = '), write(Result).

mult(N1, N2, Result):-
	Result is N1*N2.