%Power of a number
start:-
	write('Enter base of the number: '),	%Prompt for the base
	read(Num),	%Reading base
	write('Enter exponent of the number: '),	%Prompt for the base
	read(Pow),	%Reading exponent
	
	power(Num, Pow, Ans),
	write(Num), write('^'), write(Pow), write(' = '), write(Ans).

power(Num, Pow, Ans):- 
	Ans is Num**Pow.