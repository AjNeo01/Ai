%Check whether X is a member of L
start:-
	write('Enter a list: '),	%Prompt to enter a list
	read(L),	%Reading the list
	
	(is_list(L) ->	%Checks if the input term is indeed a list
		write('Enter the element to check membership: '),
		read(X),
		memb(X, L)	%Function call
	;	write('Invalid input.\n'),
		start	%Retry if not a list
	).

	
memb(X, L):-	%Function to check membership
	(member(X, L) ->
		write(X), write(' is a member of the list.')
	;	write(X), write(' is not a member of the list.')
	).